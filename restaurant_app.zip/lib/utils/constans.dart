class Constans {
  static String baseUrlApi = 'https://restaurant-api.dicoding.dev/';
}
