enum ResultState { loading, noData, hashData, errors }
